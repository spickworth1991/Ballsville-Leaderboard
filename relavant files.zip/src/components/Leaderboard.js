import { useState, useEffect } from "react";
import OwnerModal from "./OwnerModal";

export default function Leaderboard({ data }) {
  const sortedOwners = [...data.owners].sort((a, b) => b.total - a.total);

  const itemsPerPage = 25;
  const [page, setPage] = useState(1);
  const totalPages = Math.ceil(sortedOwners.length / itemsPerPage);

  const startIndex = (page - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentOwners = sortedOwners.slice(startIndex, endIndex);

  useEffect(() => {
    setPage(1); // reset page when data changes
  }, [data]);

  const [selectedOwner, setSelectedOwner] = useState(null);
  const uniqueLeagues = new Set(sortedOwners.map(o => o.leagueName));
  const showLeagueColumn = uniqueLeagues.size > 1;

  return (
    <div className="overflow-x-auto animate-fadeIn">
      {sortedOwners.length === 0 ? (
        <p className="text-center text-gray-400">No owners available.</p>
      ) : (
        <>
          <table className="min-w-full bg-gray-900 rounded-lg shadow-lg">
            <thead>
              <tr className="text-left text-gray-300 bg-gray-800">
                <th className="p-3">Rank</th>
                <th className="p-3">Owner</th>
                {showLeagueColumn && <th className="p-3">League</th>}
                {data.weeks.map(w => (
                  <th key={w} className="p-3">W{w}</th>
                ))}
                <th className="p-3">Total</th>
              </tr>
            </thead>
            <tbody>
              {currentOwners.map((o, idx) => (
                <tr
                  key={`${o.ownerName}-${idx}`}
                  className="hover:bg-gray-800 cursor-pointer transition"
                  onClick={() => setSelectedOwner(o)}
                >
                  <td className="p-3">{startIndex + idx + 1}</td>
                  <td className="p-3">{o.ownerName}</td>
                  {showLeagueColumn && <td className="p-3">{o.leagueName}</td>}
                  {data.weeks.map(w => (
                    <td key={w} className="p-3">{o.weekly[w]?.toFixed(2) || "-"}</td>
                  ))}
                  <td className="p-3 font-bold">{o.total}</td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex justify-center items-center gap-4 mt-4">
              <button
                onClick={() => setPage(p => Math.max(p - 1, 1))}
                disabled={page === 1}
                className="px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded disabled:opacity-50"
              >
                Prev
              </button>
              <span className="text-white">Page {page} of {totalPages}</span>
              <button
                onClick={() => setPage(p => Math.min(p + 1, totalPages))}
                disabled={page === totalPages}
                className="px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded disabled:opacity-50"
              >
                Next
              </button>
            </div>
          )}
        </>
      )}

      {selectedOwner && (
        <OwnerModal
          owner={selectedOwner}
          onClose={() => setSelectedOwner(null)}
          allOwners={data.owners}
        />
      )}
    </div>
  );
}
