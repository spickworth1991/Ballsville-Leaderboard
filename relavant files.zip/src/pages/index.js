import { useEffect, useState } from "react";
import Link from "next/link";
import OwnerModal from "../components/OwnerModal";

export default function HomePage() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedOwner, setSelectedOwner] = useState(null);
  const [showWeeks, setShowWeeks] = useState(false);

  useEffect(() => {
    fetch("/data/leaderboard.json")
      .then(res => res.json())
      .then(json => {
        setData(json);
        setLoading(false);
      });
  }, []);

  if (loading) return <div className="text-center text-white mt-10">Loading leaderboard...</div>;

  const sortedOwners = [...data.owners].sort((a, b) => b.total - a.total);

  return (
    <div className="min-h-screen bg-black text-white p-6">
      <div className="text-center mb-6">
        <div className="bg-gray-700 inline-block px-6 py-3 rounded-xl text-3xl font-bold animate-pulse">
          LOGO HERE
        </div>
      </div>

      <h1 className="text-4xl font-bold text-center mb-4">Combined Leaderboard</h1>

      {/* Warning only when weekly scores are visible */}
      {showWeeks && (
        <p className="text-center text-yellow-400 mb-4 animate-fadeIn">
          *Weekly points do not account for stat corrections; totals do.
        </p>
      )}

      {/* Toggle for weekly columns */}
      <div className="text-center mb-4 transition">
        <label className="flex items-center justify-center gap-2 cursor-pointer">
          <input
            type="checkbox"
            className="w-5 h-5"
            checked={showWeeks}
            onChange={() => setShowWeeks(!showWeeks)}
          />
          <span className="text-lg">Show Weekly Scores</span>
        </label>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border border-gray-700 rounded-lg">
          <thead>
            <tr className="bg-gray-800">
              <th className="p-3">Rank</th>
              <th className="p-3">Owner</th>
              <th className="p-3">League</th>
              {showWeeks &&
                data.weeks.map(w => (
                  <th key={w} className="p-3">W{w}</th>
                ))}
              <th className="p-3">Total Points</th>
            </tr>
          </thead>
          <tbody>
            {sortedOwners.map((owner, index) => (
              <tr
                key={`${owner.ownerName}-${index}`}
                className="border-b border-gray-700 hover:bg-gray-900 transition cursor-pointer"
                onClick={() => setSelectedOwner(owner)}
              >
                <td className="p-3">{index + 1}</td>
                <td className="p-3">{owner.ownerName}</td>
                <td className="p-3">{owner.leagueName}</td>
                {showWeeks &&
                  data.weeks.map(w => (
                    <td key={w} className="p-3">{owner.weekly[w]?.toFixed(2) || "-"}</td>
                  ))}
                <td className="p-3 font-bold">{owner.total}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="text-center mt-8 flex justify-center gap-4">
        <Link href="/divisions">
          <button className="bg-blue-600 hover:bg-blue-800 px-6 py-3 rounded-lg transition">View Divisions</button>
        </Link>
        <Link href="/league">
          <button className="bg-green-600 hover:bg-green-800 px-6 py-3 rounded-lg transition">View Leagues</button>
        </Link>
      </div>

      {selectedOwner && (
        <OwnerModal
          owner={selectedOwner}
          onClose={() => setSelectedOwner(null)}
          allOwners={data.owners} // ✅ Pass full owner list
        />
      )}

    </div>
  );
}
